								260.exe									
NOSKID!!!

Made by : Kavru (no help)
Made in : C# (My First C# Malware.)

260.exe is a 21-22 Payload Malware made in like 2-3 Hours (extra Delays by day caused by debugging and testing from errors.)

Credits : None
Works : Windows 7, 8, 8.1

Also i feel like turning this into a Number Series starting at 259 which was my last malware so now we at 260! and so on.

and also Epilepsy warning of Course!	

And Enjoy!