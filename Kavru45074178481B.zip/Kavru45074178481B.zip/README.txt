you just downloaded "Kavru45074178481B.exe" and thank you. Info about Malware below.

Made in : C++
8 Payloads (Short Malware)
made by : Kavru (Solo)
Started October 29th and finished October 31th.

and a few side notes, Some effects might lag (i forgot which payload or payloads it was.)

and yeah Enjoy!

Also Run as admin.



- Kavru :D