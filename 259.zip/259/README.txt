	259.exe is

a Joke Malware so there no real effort put into this.

Made in : C
Damage Rate : Extremely Low
Made by : Kavru

Note : 


Enjoy!



ALSO im not sure if it has an end so idk, it might be endless.
